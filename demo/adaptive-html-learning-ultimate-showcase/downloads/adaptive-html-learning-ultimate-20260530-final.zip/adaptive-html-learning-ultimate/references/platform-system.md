# Platform System

## Tistory

검색형 제목, 목차, HTML 호환성, 본문 중간 소제목, 하단 태그를 중시한다.

## Velog

Markdown 중심, 코드블럭, 개발자 문체, 짧은 문제/해결 흐름을 중시한다.

## Naver Blog

짧은 문단, 경험형 서술, 이미지 위치 제안, 검색 친화적 반복 키워드를 사용한다.

## WordPress/GitHub Pages

slug, meta, JSON-LD, 내부 링크 설계, canonical, schema 구조를 고려한다.
