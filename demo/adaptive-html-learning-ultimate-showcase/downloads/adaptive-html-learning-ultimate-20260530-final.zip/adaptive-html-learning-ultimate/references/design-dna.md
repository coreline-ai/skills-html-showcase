# Design DNA

핵심은 “따뜻한 학습지 + 매거진형 타이포그래피 + 박스형 설명”이다.

## 고정 요소

- 오프화이트 배경 `#f5f5f0`
- Pretendard Variable + Noto Serif KR 조합
- 빨간 원형 번호 h2
- h2-sub 부제 리듬
- 780px 읽기 폭 / 1020px 분석 폭
- term, analogy, danger, good, hero-analogy, try 박스
- source-note로 낮춘 출처

## 금지

- 과한 SaaS 랜딩페이지 스타일
- Tailwind CDN, 외부 JS 라이브러리
- 불필요한 아이콘 폰트
- 근거 없는 메타 정보
- 검정 hero 박스 남발
