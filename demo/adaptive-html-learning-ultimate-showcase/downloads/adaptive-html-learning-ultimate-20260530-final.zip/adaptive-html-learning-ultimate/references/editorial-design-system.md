# Editorial Design System

`adaptive-html-blog-writer-v2`는 7개 모드 구조를 유지하되, 출력물은 고급 한국어 기술 블로그/학습지처럼 보여야 한다.

## 디자인 토큰

고정 방향:

- 배경: 따뜻한 오프화이트 `#f5f5f0`
- 본문: 거의 검정 `#1a1a1a`
- 보조 텍스트: `#4a4a4a`, `#7a7a7a`
- 강조: 빨강 `#e63946`
- 카드: 흰색 + 얇은 border
- 그림자: 거의 사용하지 않음
- radius: 5~12px, 과한 pill/round 금지

## 타이포그래피

- H1/H2: `Noto Serif KR`
- 본문: `Pretendard Variable`
- H1: 31~42px, line-height 1.3 이상
- H2: 24~29px, 위쪽 여백 52~64px
- 본문: 15.5px, line-height 1.75~1.8

긴 한국어 제목은 너무 크게 만들면 품질이 떨어진다. “크게”보다 “읽기 좋은 줄바꿈”이 우선이다.

## 섹션 구조

권장 패턴:

```html
<h2><span class="num">1</span>섹션 제목</h2>
<p class="h2-sub">이 섹션에서 독자가 얻게 될 것을 한 줄로 설명한다.</p>
<p>본문...</p>
```

`h2-sub`는 콘텐츠 리듬을 만드는 핵심 장치다. beginner, article, education, blog 모드에서는 대부분의 h2에 둔다.

## 의미 박스

### 용어

```html
<div class="term">
  <div class="label">용어</div>
  <span class="word">PKCE (Proof Key for Code Exchange)</span>
  <div class="meaning">인가 코드 탈취를 막기 위한 OAuth 확장...</div>
</div>
```

### 비유

```html
<div class="analogy">
  <div class="label">비유로 이해하기</div>
  <p>추상 개념을 일상 사례로 설명한다.</p>
</div>
```

### 함정/해결

함정은 `.danger`, 해결은 `.good`으로 가능하면 짝지어 쓴다.

```html
<div class="danger"><div class="label">함정</div><div class="name">잘못된 직관</div><p>설명...</p></div>
<div class="good"><div class="label">해결</div><div class="name">권장 패턴</div><p>설명...</p></div>
```

## 강조

- 짧은 용어: `<em class="t">용어</em>`
- 핵심 구절: `<span class="hl">핵심 문장</span>`
- `.hl`은 글당 2~4개만 사용한다.
- 색상 박스 안에는 `.hl`을 쓰지 않는다.

## 출처

본문 끝 출처는 작고 조용해야 한다.

```html
<aside class="source-note">
  <div class="label">출처와 검토 기준</div>
  <p>OWASP, NIST, RFC 문서를 검토해 작성했습니다.</p>
  <p><a href="sources/index.html">전체 출처 링크 모음 보기</a></p>
</aside>
```

출처 링크가 6개를 넘으면 대량 목록을 본문에 넣지 말고 source hub로 분리한다.

## Golden reference

현재 프로젝트 기준 좋은 예시는 `blog-demos/` 계열이다. 특히 다음 특성을 모방한다.

- 차분한 오프화이트 배경
- serif 제목과 sans 본문 조합
- h2 숫자 원 + h2-sub
- 의미 라벨이 있는 term/analogy/danger/good
- 마지막 검정 `.try` 박스
- source-note로 낮춘 출처
