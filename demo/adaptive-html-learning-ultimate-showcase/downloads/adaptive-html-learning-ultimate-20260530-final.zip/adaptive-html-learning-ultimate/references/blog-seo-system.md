# Blog SEO System

제목은 검색형, 클릭형, 전문가형, 초보자형으로 나눈다.

메타 설명은 120~160자 내외를 목표로 한다. 확인되지 않은 수치와 최신 주장은 넣지 않는다.

SERP preview는 title, slug, meta description을 함께 보여준다.

## Required SEO blocks

- primary keyword
- secondary keyword cluster
- title candidates
- meta description candidates
- SERP preview
- final SEO set
- FAQ 후보
- internal link 후보

## Tone

검색 유입 독자에게 즉시 가치를 전달하되, 낚시성 제목과 과장된 최신성 표현은 피한다.
