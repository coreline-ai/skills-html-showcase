# Eval Rubric

각 항목 0~5점.

| 항목 | 기준 |
|---|---|
| Mode Fit | 요청과 모드가 맞는가 |
| Layout Fit | 정보 구조가 목적에 맞는가 |
| Design DNA | 현재 editorial 테마가 유지되는가 |
| Content Depth | 설명/예시/주의/행동이 충분한가 |
| SEO/A11y | 메타/heading/모바일이 적절한가 |
| Factuality | 확인 필요를 단정하지 않는가 |
| Source Handling | 출처를 과하게 노출하지 않고 검증 가능하게 제공하는가 |

총점 28점 이상이면 통과, 24~27점은 보완 후 통과, 23점 이하는 재작성.
