이 내용을 전문가용 HTML 리포트로 만들어줘. Executive Summary, 리스크, 개선 우선순위, 검증 체크리스트를 포함해줘.
