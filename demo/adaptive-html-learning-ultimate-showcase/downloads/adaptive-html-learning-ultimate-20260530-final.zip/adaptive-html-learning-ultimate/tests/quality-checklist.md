# Quality Checklist

- [ ] 요청 목적과 선택 모드가 일치한다.
- [ ] 선택 모드의 필수 블록이 모두 있다.
- [ ] `lang="ko"`, viewport, title, meta description이 있다.
- [ ] h1은 1개다.
- [ ] CSS 3개 또는 base inline CSS가 있다.
- [ ] H1이 한국어 긴 제목에서 과도하게 크지 않다.
- [ ] 주요 h2에 `.h2-sub`가 있다.
- [ ] 공통 컴포넌트를 5개 이상 사용했다.
- [ ] `.hl`은 2~4개이며 색상 박스 내부에 없다.
- [ ] 표는 모바일 안전하다.
- [ ] 출처가 많으면 `.source-note` + source hub로 분리했다.
- [ ] 외부 JS를 사용하지 않는다.
- [ ] JSON-LD가 있으면 valid JSON이다.
- [ ] 브라우저에서 1280px/390px 스크린샷 확인이 가능하다.
