# Layout Checklist

생성된 HTML을 릴리즈하기 전 확인한다.

- [ ] `lang="ko"`가 있다.
- [ ] title/meta description이 있다.
- [ ] h1은 1개다.
- [ ] CSS 3개를 연결한다: `assets/theme.css`, `assets/components.css`, `assets/layouts.css`.
- [ ] 공개 블로그라면 Pretendard/Noto Serif KR 폰트 링크가 있다.
- [ ] H1이 한국어 긴 제목에서 과도하게 크지 않다.
- [ ] 주요 h2에 `.h2-sub`가 있다.
- [ ] `.term`, `.analogy`, `.danger`, `.good`, `.try`, `.source-note` 중 5개 이상을 적절히 사용한다.
- [ ] `.hl`은 2~4개이며 색상 박스 내부에 없다.
- [ ] 출처 링크가 많으면 `.source-note` + `sources/index.html`로 분리한다.
- [ ] 모바일 폭에서 그리드가 1컬럼이다.
- [ ] 표는 `.tbl` wrapper 또는 모바일 안전 구조다.
- [ ] 외부 JS를 사용하지 않는다.
