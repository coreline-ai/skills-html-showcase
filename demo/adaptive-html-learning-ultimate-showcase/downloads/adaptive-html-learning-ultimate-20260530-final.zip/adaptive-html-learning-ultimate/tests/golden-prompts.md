# Golden Prompts

1. Docker를 초보자용 HTML 학습자료로 만들어줘.
2. MCP Gateway 설계를 전문가 리포트 HTML로 검토해줘.
3. AI 시대 개인 지식 블로그에 대한 공개 아티클을 만들어줘.
4. GitHub Pages 교육용 HTML을 만들어줘. 퀴즈 포함.
5. Mac mini를 개인 AI 서버로 쓰는 블로그 글을 작성해줘.
6. GraphRAG 입문 글의 SEO 제목/메타/태그를 만들어줘.
7. 같은 글을 티스토리/벨로그/네이버/워드프레스용으로 바꿔줘.
8. 이 SKILL.md를 분석하고 개선본을 만들어줘.
