# Adaptive HTML Learning Ultimate

13개 모드 라우터와 blog-demos급 editorial design system을 통합한 한국어 HTML 콘텐츠 생성 스킬입니다.

## 핵심

- 기존 v2의 7개 모드 유지: beginner, expert, article, education, blog, seo, platform
- ultimate 확장 모드 추가: skill_audit, reference, comparison, case_study, landing_brief, checklist_playbook
- 현재 디자인 유지: 오프화이트 배경, Pretendard + Noto Serif KR, h2-sub, 의미 박스, source-note

## 주요 파일

- `SKILL.md`: 최종 워크플로우와 모드 라우터
- `assets/theme.css`: 공통 editorial 테마
- `assets/components.css`: 박스/하이라이트/표/출처 컴포넌트
- `assets/layouts.css`: 모드별 레이아웃 차이
- `assets/base.html`: 단일 HTML 렌더링 골격
- `assets/print.css`: 인쇄 대응
- `assets/layouts/*.html`: 13개 레이아웃 템플릿
- `references/*.md`: 필요 시 로드하는 세부 규칙
- `recipes/*.md`: 대표 요청 프롬프트
- `schemas/*.json`: 메타/품질 리포트 스키마
